import 'package:flutter/material.dart';

class constructor extends StatefulWidget {


  Container myArticles(String imagVal, String heading) {
    return Container(
      width: 90,
      child: Wrap(
        children: [
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(79.0),
              child: Image.asset(imagVal,
                  width: 70,
                  height: 70),
            ),
          ),
          ListTile(
            title: Center(
              child: Text(heading,
                style: TextStyle(
                    fontSize: 13,
                    color: Colors.white,
                  fontFamily: "Segoe UI",
                ),),
            ),
          ),
        ],
      ),
    );
  }
  Image myImages (String imageAssets){
    return Image.asset(imageAssets,
        fit: BoxFit.cover,
        width:340);
  }
  Container featureArticle(String featImage, String featTitle, String featprice) {
    return Container(
      padding: EdgeInsets.only(left: 20),
      width: 160,
      child: Card(
        elevation: 5,
        child: GestureDetector(

          child: Wrap(
            children: [
              Center(
                child: Image.asset(featImage,
                    width: 90,
                    height: 95),
              ),
              ListTile(
                title: Text(featTitle,

                  style: TextStyle(
                      fontSize: 14,
                      color: Colors.black,
                    fontFamily: "Segoe UI",
                    fontWeight: FontWeight.w300,

                  ),),
                subtitle: Text(featprice,

                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.black,
                    fontFamily: "Segoe UI",
                    fontWeight: FontWeight.w800,

                  ),),
              )
            ],
          ),
        ),
      ),
    );
  }
  Container categoryseeAll(String categorytitle, String sub_category_title) {
    return Container(
      width: 390,
      child: ListTile (
        title: Text(categorytitle,
          style: TextStyle(
          fontSize: 24.0,
          color: Colors.black54,
          fontFamily: "Segoe UI",
        ),
        ),
        trailing: Text(sub_category_title,
          style: TextStyle(
            fontSize: 16.0,
            color: Colors.black45,
            fontFamily: "Segoe UI",
          ),
        ),
      ),
    );
  }
  Container fruittext(String fruitimage, String fruittext){
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 05.0),
      width: 60,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(9.0),
        child: Wrap(
          children: [
            Container(
              height: 60,
              child: Center(
                child: Image.asset(fruitimage,
                    width: 35,
                    height: 35),
              ),
            ),
            Center(
              child: Text(fruittext,
              style: TextStyle(
                fontSize: 11,
                color: Colors.black,
                fontWeight: FontWeight.w400,
                fontFamily: "Segoe UI",
              ),
              ),
            ),
          ],

        ),
      ),
    );
  }
  Container netWEIGHT(String netWEIGHT){
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5.0),

      width: 60,
      child: Wrap(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(9.0),
            child: Container(
              margin: EdgeInsets.only(bottom: 35.0),
              height: 60,
            width: 60,
              color: Color(0xffF3F3F3),
              child: Center(
                child: Text(netWEIGHT,

                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                  fontFamily: "Segoe UI",
                ),
                ),
              ),
            ),
          ),
        ],

      ),
    );
  }


  @override
  State<constructor> createState() => _constructorState();
}


class _constructorState extends State<constructor> {
  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
