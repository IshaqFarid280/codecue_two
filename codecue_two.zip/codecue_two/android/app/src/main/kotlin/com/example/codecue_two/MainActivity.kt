package com.example.codecue_two

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
